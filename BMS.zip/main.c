#include <stdio.h>
#include <stdint.h>

#define number_of_cells 4
#define max_cell_voltage 4200
#define min_cell_voltage 3000
#define imbalance_cell_voltage 200

#define normal_flag 0x00
#define under_voltage_flag 1
#define over_voltage_flag 1 << 1
#define imbalance_voltage_flag 2 << 1

typedef struct
{
    uint16_t cells_voltage[number_of_cells]; // based on milivoltage
    uint16_t total_voltage;
    uint16_t relay_situation; // 0->off 1->on
    uint8_t error_flag;
} BMS_State_t;

// for get total voltage of cells
uint16_t get_total_battery(const BMS_State_t *bms)
{
    uint16_t total = 0;
    for (uint8_t i = 0; i < number_of_cells; i++)
    {
        total += bms->cells_voltage[i];
    }
    return total;
}

// for calc min and max voltage
void get_min_max(const BMS_State_t *bms, uint16_t *min, uint16_t *max)
{
    *max = bms->cells_voltage[0];
    *min = bms->cells_voltage[0];
    for (uint8_t i = 1; i < number_of_cells; i++)
    {
        if (*max < bms->cells_voltage[i])
        {
            *max = bms->cells_voltage[i];
        }
        if (*min > bms->cells_voltage[i])
        {
            *min = bms->cells_voltage[i];
        }
    }
}

// core logic process function
void BMS_Process(BMS_State_t *bms_handle)
{
    bms_handle->total_voltage = get_total_battery(bms_handle);

    uint16_t max_voltage, min_voltage;
    get_min_max(bms_handle, &min_voltage, &max_voltage);

    bms_handle->error_flag = 0;
    bms_handle->relay_situation = 1;

    if (min_voltage < min_cell_voltage)
    {
        bms_handle->relay_situation = 0;
        bms_handle->error_flag |= under_voltage_flag;
    }
    if (max_voltage > max_cell_voltage)
    {
        bms_handle->relay_situation = 0;
        bms_handle->error_flag |= over_voltage_flag;
    }
    if (max_voltage - min_voltage > imbalance_cell_voltage)
    {
        bms_handle->error_flag |= imbalance_voltage_flag;
    }
}

void print_binary(uint8_t n)
{
    if (n > 1)
    {
        print_binary(n >> 1);
    }
    printf("%d", n & 1);
}

void show_battery_info(BMS_State_t *bms)
{
    BMS_Process(bms);
    printf("relay situation : %d\n", bms->relay_situation);
    printf("error code : ");
    print_binary(bms->error_flag);
}

void initial_battery(BMS_State_t *bms, const uint16_t b1, const uint16_t b2, const uint16_t b3, const uint16_t b4)
{
    bms->cells_voltage[0] = b1;
    bms->cells_voltage[1] = b2;
    bms->cells_voltage[2] = b3;
    bms->cells_voltage[3] = b4;
}

int main()
{
    BMS_State_t bms;
    initial_battery(&bms, 4310, 3050, 3030, 3040);

    show_battery_info(&bms);

    return 0;
}